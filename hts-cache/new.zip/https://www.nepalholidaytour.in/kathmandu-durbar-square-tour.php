<!DOCTYPE html><html dir="ltr" lang="en"><head><meta name="viewport" content="width=device-width,initial-scale=1.0" /><meta charset="utf-8">
<title>Kathmandu Durbar Square Tour </title>
<meta name="description" content="Visit World Heritage Sites in Kathmandu with M & M Tour and Travels. We are reliable and trusted tour operator for nepal in Gorakhpur. Book your Kathmandu trip with us and get best offer price."/>
<meta name="keywords" content="Kathmandu Durbar Square Tour, World Heritage Sites in Kathmandu, Durbar Square of Kathmandu."/>
<meta property="og:title" content="Kathmandu Durbar Square Tour."/><meta property="og:site_name" content="M & M Tour and Travels"/><meta property="og:url" content="https://www.nepalholidaytour.in/kathmandu-durbar-square-tour.php"/><meta property="og:description" content="Visit World Heritage Sites in Kathmandu with M & M Tour and Travels. We are reliable and trusted tour operator for nepal in Gorakhpur. Book your Kathmandu trip with us and get best offer price."/><meta property="og:type" content="Service"/><meta property="og:image" content="https://www.nepalholidaytour.in/img/durbar-square-kathmandu.jpg"/>
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@ M & M Tour and Travels">
<meta name="twitter:title" content="Kathmandu Durbar Square Tour.">
<meta name="twitter:description" content="Visit World Heritage Sites in Kathmandu with M & M Tour and Travels. We are reliable and trusted tour operator for nepal in Gorakhpur. Book your Kathmandu trip with us and get best offer price.">
<meta name="twitter:image" content="https://www.nepalholidaytour.in/img/durbar-square-kathmandu.jpg">
<meta name="Revisit-After" CONTENT="7 Days"/>
<meta name="distribution" content="global"/>
<meta name="document-type" content="Public"/>
<meta name="Classification" content="Kathmandu Durbar Square, Kathmandu Durbar Square Tour, World Heritage Sites in Kathmandu, Durbar Squares of Bhaktapur and Patan."/>
<link rel="canonical" href="https://www.nepalholidaytour.in/kathmandu-durbar-square-tour.php" />
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-79EBH6BS1M"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-79EBH6BS1M');
</script>
<link rel="icon" type="image/png" href="img/m-logo.png">
<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/magnific-popup.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/meanmenu.min.css">
<link rel="stylesheet" href="css/icofont.min.css">
<link rel="stylesheet" href="css/linearicons-min.css">
<link rel="stylesheet" href="css/responsive.css">
</head><script src="../../../../widget-v4.tidiochat.com/1_35_0/static/js/render.c25d885567cc682a9c5b.js" async></script>
<header class="header-sec">
<div class="header-top">
<div class="container">
<div class="row">
    <div class="col-md-7">
       <h4>Nepal Tour Package From Gorakhpur | Nepal Holiday Tour From Gorakhpur</h4> 
    </div>
    <div class="col-md-2">
        <ul>
            <li><i class="icofont-telephone"></i>+91-7309884998</li>
            </ul>
    </div>
    <div class="col-md-3">
        <ul>
            <li><i class="icofont-email"></i> mmtravelsgkp@gmail.com</li>
            </ul>
    </div></div></div></div>
<div class="hd-sec" style="color:white;">
<div class="container" style="color:white;">
<div class="row" style="background-color:white;">
<div class="col-md-4 col-sm-12 col-xs-8 classic-logo">
<a href="index.php"><img src="img/mm-logo.png" alt="MM Tour and Travels Gorakhpur Logo" style="padding-top:5px;"></a>
</div>
<div class="col-md-3 col-xs-8 responsive-logo">
<a href="index.php">
    <img src="img/mm-logo.png" alt="Logo of MM Tour and Travel Gorakhpur " style="padding-top:10px;">
    </a>
</div>
<div class="mobile-nav-menu"></div>
<div class="col-md-8 col-sm-12 nav-menu">
<div class="menu">
<nav id="main-menu" class="main-menu">
<ul>
<li><a href="index.php">Home</a>
<li><a href="about.php">About Us</a></li>
<li><a href="#">Tour Destinations</a>
<ul>
            <li><a href="pokhara-tour-package-from-gorakhpur.php">Pokhara Tour Package</a></li>
            <li><a href="kathmandu-tour-package-from-gorakhpur.php">Kathmandu Tour Package</a></li>
            <li><a href="muktinath-tour-package-from-gorakhpur.php">Muktinath Tour Package</a></li>
            <li><a href="">Chitwan Tour Package</a></li>
            <li><a href="">Bandipur Tour Package</a></li>
            <li><a href="">Lumbini Tour Package</a></li>
            <li><a href="">Trekking Tour Package</a></li>
            <li><a href="">Adventure Tour Package</a></li>
         </ul>
     </li>
<li><a href="">Transportation</a></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav></div> </div></div>
</header>
<div class="pagehding-sec">
<div class="images-overlay"></div>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="page-heading">
</div>
<div class="page-breadcrumb-inner">
<div class="page-breadcrumb">
<div class="breadcrumb-list">
</div></div></div></div></div></div></div>
<section id="bison">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Kathmandu Durbar Square</h1>
                        <p>Kathmandu Durbar Square is a historic and cultural site located in the heart of Kathmandu, the capital city of Nepal. It is one of the three Durbar Squares (royal palaces) in the Kathmandu Valley, the other two being Bhaktapur Durbar Square and Patan Durbar Square. Kathmandu Durbar Square is a UNESCO World Heritage Site and is known for its architectural grandeur and rich cultural heritage. The square was once the royal palace of the Malla and Shah kings who ruled over the Kathmandu Valley. It served as the seat of power for several dynasties and witnessed the coronation of Nepalese kings. The square is home to numerous palaces, temples, statues, and courtyards, reflecting a blend of Hindu and Buddhist architectural styles.</p>
            </div>
            <div class="col-md-6">
                <img src="img/durbar-square-kathmandu.jpg" alt=" durbar square kathmandu nepal">
                <center><strong>Durbar Square Kathmandu, Nepal</strong></center>
        </div>
    </div>
</section>
<section id="bison">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Some of the prominent structures in Kathmandu Durbar Square include :</h1>
            <h4>Hanuman Dhoka Palace: </h4> 
            <p>This complex was the royal residence of the  Malla kings and Shah dynasty and served as the seat of the Nepalese monarchy until the late 19th century. It is spread over five acres. It consists of various courtyards, museums, and historic buildings. </p>
            <h4>Taleju Temple: </h4>
            <p>Dedicated to the Hindu goddess Taleju Bhawani, this three-story pagoda-style temple is one of the tallest structures in the square. It is open to Hindus only during Dashain, a major Hindu festival. </p>
            <h4>Kumari Ghar:</h4>
            <p>Also known as the House of the Living Goddess, this building is the residence of Kumari, a young girl believed to be the living incarnation of the Hindu goddess Taleju. Visitors can catch a glimpse of the Kumari during designated times.</p>
            <h4>Basantapur Tower:</h4>
            <p>Also known as the Minnath Tower, this nine-story tower offers panoramic views of the entire Durbar Square area and its surroundings. tourists can explore the tower from the outside and the inside.</p>
            <p>Besides these, there are numerous other temples, shrines, and statues within the square, each with its own historical and cultural significance.</p>
        </div>
    </div>
</section>               
<script src="../../../../widget-v4.tidiochat.com/1_35_0/static/js/render.c25d885567cc682a9c5b.js" async></script>
<footer class="footer">
<div class="footer-overlay"></div>
<div class="footer-sec">
<div class="container">
<div class="row">
<div class="col-md-4 col-sm-6 footer-widget">
<div class="footer-wedget-one">
<h2>About us</h2>
<p>M & M Tour And Travels is a leading Tour operator for Nepal, Char-Dham Yatra, Manali, Kashmir, Gangtok & Darjeeling (Sikkim). We provide customised Tour Packages for Nepal from Gorakhpur. We have our own range of luxury vehicles across big (Bus & Tempo Traveller) and small ( Car) segments which helps in making travel convenient and affordable.</p>
</div>
</div>
<div class="col-md-3 col-sm-6 footer-widget">
    <div class="footer-widget-menu">
        <h2>Tour Packages</h2>
            <ul>
<li><a href="">Kathmandu Tour Package</a></li>
<li><a href="">Pokhara Tour Package</a></li>
<li><a href="">Chitwan Jungle safari</a></li>
<li><a href="muktinath-tour-package-from-gorakhpur.php">Muktinath Tour Package</a></li>
<li><a href="">Char Dham Yatra Package</a></li>
<li><a href="">Manali Tour Package</a></li>
            </ul>
    </div>
</div>
<div class="col-md-2 col-sm-6 footer-widget">
    <div class="footer-widget-menu">
        <h2>useful link</h2>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="">About </a></li>
                <li><a href="">Picture Gallery</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
</div>
<div class="col-md-3 col-sm-6 footer-widget">
    <h2>Our Address</h2>
        <div class="footer-contact-info-text">
            <span style="color:white;">
            Aluminium Factory Rd, Basharatpur, Gorakhpur, Uttar Pradesh - 273004</span>
       </div>
        <div class="footer-contact-info-text">
            <span style="color:white;"> mmtravelsgkp@gmail.com</span>
        </div>
        <div class="footer-contact-info-text">
        <span style="color:white;">+91-7309884998, 9792733733</span>
    </div>
</div>
   <div class="whatsapp">
	      <a href="#" target="_blank" width="10%"><img src="img/fb.png" class="img-responsive" alt="whatsapp"></a>
	   </div>
    <div class="whatsapp2">
	      <a href="https://api.whatsapp.com/send?phone=917309884998&amp;text=Hello%20Sir" target="_blank"><img src="img/whatsapp.png" class="img-responsive" alt="whatsapp"></a>
	   </div>
    
<div class="footer-bottom-sec">
<div class="container">
<div class="row">
<div class="col-md-7">
<div class="copy-right">
<span>&copy; 2023 M & M Tour and Travels. All right reserved.</span>
</div></div>
<div class="col-md-5">
</div></div></div></div>
</footer>
<script data-cfasync="false" src="../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="js/jquery-2.2.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/isotope.pkgd.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/owl.animate.js"></script>
<script src="js/jquery.scrollUp.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/modernizr.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/jquery.meanmenu.min.js"></script>
<script src="js/imagesloaded.pkgd.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>